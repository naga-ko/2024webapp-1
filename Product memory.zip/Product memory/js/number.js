const input = document.querySelector(".main__form-input");
const number = document.querySelector(".main__form-change");
